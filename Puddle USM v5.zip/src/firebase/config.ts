// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD4wX5a7nHVzs7C2nMjoMypFM6dJY6C7PA",
  authDomain: "puddle-cce9f.firebaseapp.com",
  projectId: "puddle-cce9f",
  storageBucket: "puddle-cce9f.appspot.com",
  messagingSenderId: "29039548226",
  appId: "1:29039548226:web:1f0340ca7921e856dc9adb"
};

export { firebaseConfig };
